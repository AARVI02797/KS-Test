<?php

/**
 * Plugin Name: Display Portfolio
 * Plugin URI: https://github.com/AARVI02797
 * Description: Display Portfolio
 * Version: 1.0
 * Author: Muhammad Ahsan Jamal
 * Author URI: https://github.com/AARVI02797
 **/

/**
 * Activate the plugin.
 */
function dp_activate()
{
    // Clear the permalinks after the post type has been registered.
    flush_rewrite_rules();
}
register_activation_hook(__FILE__, 'dp_activate');

/**
 * Deactivation hook.
 */
function dp_deactivate()
{
    // Clear the permalinks to remove our post type's rules from the database.
    flush_rewrite_rules();
}
register_deactivation_hook(__FILE__, 'dp_deactivate');

// Shortcode
function dp_fn($params)
{
    require_once __DIR__ . '/shortcode/portfolio-shortcode.php';
}
add_shortcode('Display-Portfolio', 'dp_fn');
